# HexFix

I'm trying to make this module to fix the hex grid snapping in FoundryVTT.