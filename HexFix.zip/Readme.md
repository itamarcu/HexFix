# HexFix

FoundryVTT module to fix hex grid snapping for non-standard token sizes.

This is currently hardcoded to work on flat-topped even hexes.

- when dragging tokens it will snap their center to the grid centers

- when WASDing a token it will move it in a way that I find better